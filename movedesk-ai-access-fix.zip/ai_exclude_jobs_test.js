const fs=require('fs'),vm=require('vm');
const idx=fs.readFileSync(process.argv[2]||'index.html','utf8');
const script=idx.slice(idx.indexOf('<script>')+8,idx.lastIndexOf('</script>'));
let pass=0,fail=0;const check=(n,c)=>{if(c)pass++;else{fail++;console.log('  ❌ '+n);}};
function extract(name){const m=new RegExp('function\\s+'+name+'\\s*\\(').exec(script);let i=script.indexOf('{',m.index),d=0,s=false,sc='',t=false,e=false;for(let p=i;p<script.length;p++){const c=script[p];if(e){e=false;continue;}if(c==='\\'){e=true;continue;}if(s){if(c===sc)s=false;continue;}if(t){if(c==='`')t=false;continue;}if(c==='"'||c==="'"){s=true;sc=c;continue;}if(c==='`'){t=true;continue;}if(c==='{')d++;else if(c==='}'){d--;if(d===0)return script.slice(m.index,p+1);}}}

// --- _trainKey + _aiTrainingPool behavior ---
const ctx={Number,Array,Object,Math,String,Set,console,_aiExcludedKeys:new Set()};
vm.createContext(ctx);
ctx.getJobTrainingData=()=>ctx._pool||[];
vm.runInContext('let _aiExcludedKeys=globalThis._aiExcludedKeys;'+extract('_trainKey'),ctx);
vm.runInContext(extract('_aiTrainingPool'),ctx);

const jobs=[
  {id:'a',name:'Kinsella',date:'2026-05-01',size:'4 bedroom',sqft:1886,actualHours:18.5},
  {id:'b',name:'Smith',date:'2026-04-01',size:'4 bedroom',sqft:1100,actualHours:9},
  {id:'c',name:'Jones',date:'2026-03-01',size:'3 bedroom',sqft:900,actualHours:7},
];
ctx._pool=jobs;
check('pool returns all jobs when nothing excluded',ctx._aiTrainingPool().length===3);
check('_trainKey is stable & distinct',ctx._trainKey(jobs[0])!==ctx._trainKey(jobs[1]) && ctx._trainKey(jobs[0])===ctx._trainKey({...jobs[0]}));
ctx._aiExcludedKeys.add(ctx._trainKey(jobs[0]));
check('excluding Kinsella removes exactly that job',ctx._aiTrainingPool().length===2 && !ctx._aiTrainingPool().some(j=>j.name==='Kinsella'));
ctx._aiExcludedKeys.clear();
check('reset (clear) restores full pool',ctx._aiTrainingPool().length===3);

// --- wiring checks ---
check('fresh quote resets exclusions, recalc preserves them',/function generateAIQuote\(isRecalc\)\{\s*if\(!isRecalc\)_aiExcludedKeys=new Set\(\);/.test(script));
check('neighbor pool uses filtered _aiTrainingPool',/const allData=_aiTrainingPool\(\);/.test(script));
check('vault regression uses filtered pool',/const data=_aiTrainingPool\(\)\.filter\(j=>j\.actualHours&&j\.estimatedVaults/.test(script));
check('sqft regression uses filtered pool',/const data=_aiTrainingPool\(\)\.filter\(j=>j\.actualHours&&j\.sqft/.test(script));
check('scored list captured for checkbox mapping (used jobs, then left-out weaker matches)',/_aiLastScored=scored\.concat\(_weakDropped\);/.test(script));
check('readout lists jobs with checkboxes (weaker matches unticked)',/class="ai-job-incl" data-idx="\$\{i\}" \$\{_on\?'checked':''\}/.test(script)&&/\$\{_aiLastScored\.map\(\(j,i\)=>\{\s*const _on=i<scored\.length;/.test(script));
check('weak-match filter: needs 5+ strong (within 20% of best), not on curated recalc',/if\(!_curatedPool&&_top8\.length\)\{[\s\S]{0,80}const _strong=_top8\.filter\(j=>j\.score>=_best\*0\.8\);\s*if\(_strong\.length>=5&&_strong\.length<_top8\.length\)/.test(script));
check('accessScore reads any wording',/function accessScore\(access\)\{\s*const t=String\(access\|\|''\)\.toLowerCase\(\)/.test(script));
check('readout shows match score and actual hours',/match \$\{Math\.round\(j\.score\)\}/.test(script)&&/\$\{j\.actualHours\} hrs/.test(script));
check('readout shows full detail (date/size/sqft/vaults + move/access/crew)',[/j\.date\?_e\(j\.date\)/,/j\.sqft\+' sqft'/,/vaults\+' vaults'/,/j\.moveType\?_e\(j\.moveType\)/,/accessUnload/,/j\.moveMen\+' movers'/].every(re=>re.test(script)));
check('readout shows quoted-vs-actual with ran-over flag',/Quoted \$\{qmin/.test(script)&&/ran over/.test(script)&&/const over=\(qmax&&j\.actualHours&&Number\(j\.actualHours\)>Number\(qmax\)\)/.test(script));
check('readout tags source (seed data vs your job)',/j\.fromSpreadsheet\?'seed data':'your job'/.test(script));
check('recalc button present',/onclick="recalcAIQuote\(\)"/.test(script));
check('recalcAIQuote collects unchecked into exclusions',/recalcAIQuote\(\)\{[\s\S]{0,260}if\(!cb\.checked\)[\s\S]{0,160}_aiExcludedKeys\.add\(_trainKey\(rec\)\)/.test(script));
check('resetAIExclusions clears exclusions + picks and re-runs',/function resetAIExclusions\(\)\{_aiExcludedKeys=new Set\(\);_aiKeptKeys=null;generateAIQuote\(true\);\}/.test(script));
check('fresh quote clears hand-picked set',/if\(!isRecalc\)_aiKeptKeys=null;/.test(script));
check('recalc records ticked jobs as the kept set',/recalcAIQuote\(\)\{[\s\S]{0,400}else kept\.add\(_trainKey\(rec\)\)[\s\S]{0,60}_aiKeptKeys=kept;/.test(script));
check('curated recalc uses ONLY ticked jobs (no refill)',/const _curatedPool=_aiKeptKeys\?_cands\.filter\(j=>_aiKeptKeys\.has\(_trainKey\(j\)\)\):null;/.test(script)&&/const _pool=_curatedPool\|\|/.test(script));

// --- behaviour: dropping 3 of 8 leaves 5, not a refilled 8 ---
{
  const cands=Array.from({length:12},(_,i)=>({id:'j'+i,name:'Job'+i,date:'2026-01-'+(10+i),actualHours:5+i,sqft:1000}));
  const top8=cands.slice(0,8);
  const kept=new Set(top8.filter((_,i)=>![1,4,6].includes(i)).map(j=>ctx._trainKey(j)));
  const curated=cands.filter(j=>kept.has(ctx._trainKey(j)));
  const scored=curated.slice(0,8);
  check('after unticking 3 of 8, estimate uses exactly the 5 kept',scored.length===5&&!scored.some(j=>['j1','j4','j6','j8','j9'].includes(j.id)));
}
check('empty-state offers reset when jobs hidden',/hidden '\+_aiExcludedKeys\.size[\s\S]{0,140}resetAIExclusions\(\)/.test(script));
check('readout copy stresses non-destructive',/this estimate only[\s\S]{0,120}Nothing is deleted/.test(script));

console.log('\nRESULTS: '+pass+' passed, '+fail+' failed');
if(!fail)console.log('ALL TESTS PASSED ✅');
process.exit(fail?1:0);
