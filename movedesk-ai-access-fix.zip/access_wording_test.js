// accessScore understands real-world wording (2026-10-01).
const fs=require('fs'),vm=require('vm');
const idx=fs.readFileSync(process.argv[2]||'index.html','utf8');
const script=idx.slice(idx.indexOf('<script>')+8,idx.lastIndexOf('</script>'));
let pass=0,fail=0;const check=(n,c)=>{if(c)pass++;else{fail++;console.log('  ❌ '+n);}};
function ex(name){const m=new RegExp('function\\s+'+name+'\\s*\\(').exec(script);let i=script.indexOf('{',m.index),d=0,s=false,sc='',t=false,e=false;for(let p=i;p<script.length;p++){const c=script[p];if(e){e=false;continue;}if(c==='\\'){e=true;continue;}if(s){if(c===sc)s=false;continue;}if(t){if(c==='`')t=false;continue;}if(c==='"'||c==="'"){s=true;sc=c;continue;}if(c==='`'){t=true;continue;}if(c==='{')d++;else if(c==='}'){d--;if(d===0)return script.slice(m.index,p+1);}}}
const ctx={String,Number,Math};vm.createContext(ctx);vm.runInContext(ex('accessScore'),ctx);const a=ctx.accessScore;
[['Flat',0],['1 Flight',1],['2 Flight',2],['3 Flight',3],['Elevator',0.5],['1 flight',1],['2 flights',2],['3 flights',3],['Two flights',2],['3rd floor walk-up',1],['Elevator with long walk',1],['Long walk',0.5],['Stairs',1],['',0],[null,0],['Ground floor',0],['5 flights',4]].forEach(([w,v])=>check(JSON.stringify(w)+' → '+v,a(w)===v));
check('generateAIQuote uses accessScore for input and jobs',/const inputAccessScore=accessScore\(inputs\.accessLoad\)\+accessScore\(inputs\.accessUnload\);/.test(script)&&/const ls=accessScore\(j\.accessLoad\);/.test(script));
check('no exact-match access map left',!/\{'Flat':0,'1 Flight':1,'2 Flight':2,'3 Flight':3,'Elevator':0\.5\}/.test(script));
console.log('\nRESULTS: '+pass+' passed, '+fail+' failed');if(!fail)console.log('ALL TESTS PASSED ✅');process.exit(fail?1:0);
