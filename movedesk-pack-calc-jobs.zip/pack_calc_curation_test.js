// Packing calculator: see comparable jobs, untick, recalculate (2026-09-30).
const fs=require('fs');
const idx=fs.readFileSync(process.argv[2]||'index.html','utf8');
const script=idx.slice(idx.indexOf('<script>')+8,idx.lastIndexOf('</script>'));
let pass=0,fail=0;const check=(n,c)=>{if(c)pass++;else{fail++;console.log('  ❌ '+n);}};
check('input changes reset exclusions',/function calcPackMaterials\(isRecalc\)\{\s*if\(isRecalc!==true\)_pcExcludedKeys=new Set\(\);/.test(script));
check('inputs still call calcPackMaterials() with no args',/id="pc-size" onchange="calcPackMaterials\(\)"/.test(idx));
check('numbers use only ticked jobs',/const histUsed=histAll\.filter\(h=>!_pcExcludedKeys\.has\(_pcKey\(h\)\)\);/.test(script)&&/const histAmounts=histUsed\.map\(h=>h\.amt\);/.test(script));
check('source counts follow ticked jobs',/histFromCompleted=histUsed\.filter/.test(script));
check('job list with checkboxes',/class="pc-job-incl" data-idx="\$\{i\}"/.test(script));
check('recalc button wired',/onclick="recalcPackMaterials\(\)"/.test(script));
check('recalc rebuilds exclusions from unticked boxes',/function recalcPackMaterials\(\)\{[\s\S]{0,300}if\(h&&!cb\.checked\)ex\.add\(_pcKey\(h\)\)[\s\S]{0,80}calcPackMaterials\(true\)/.test(script));
check('reset clears and recalculates',/function resetPackMaterialsExclusions\(\)\{_pcExcludedKeys=new Set\(\);calcPackMaterials\(true\);\}/.test(script));
check('all-hidden state offers reset',/All \$\{_pcHidden\} comparable jobs are hidden/.test(script));
check('job rows show detail (size, sqft, pack hours)',/h\.sqft\+' sqft'/.test(script)&&/h\.packHours\+' pack hrs'/.test(script));
check('names escaped',/const nm=_pcE\(h\.name\)/.test(script));
console.log('\nRESULTS: '+pass+' passed, '+fail+' failed');
if(!fail)console.log('ALL TESTS PASSED ✅');
process.exit(fail?1:0);
