// Multi-day completion: per-day packing materials must reach feePackMaterials (2026-09-30).
const fs=require('fs'),vm=require('vm');
const idx=fs.readFileSync(process.argv[2]||'index.html','utf8');
const script=idx.slice(idx.indexOf('<script>')+8,idx.lastIndexOf('</script>'));
let pass=0,fail=0;const check=(n,c)=>{if(c)pass++;else{fail++;console.log('  ❌ '+n);}};
function extract(name){const m=new RegExp('function\\s+'+name+'\\s*\\(').exec(script);let i=script.indexOf('{',m.index),d=0,s=false,sc='',t=false,e=false;for(let p=i;p<script.length;p++){const c=script[p];if(e){e=false;continue;}if(c==='\\'){e=true;continue;}if(s){if(c===sc)s=false;continue;}if(t){if(c==='`')t=false;continue;}if(c==='"'||c==="'"){s=true;sc=c;continue;}if(c==='`'){t=true;continue;}if(c==='{')d++;else if(c==='}'){d--;if(d===0)return script.slice(m.index,p+1);}}}

// --- structural: new completions and edits save packing materials ---
const cmd=extract('confirmCompleteMultiDay');
check('completion sums per-day packing materials',/aggPackMaterials\+=packMaterials/.test(cmd));
check('completion saves feePackMaterials from the sum',/feePackMaterials:String\(aggPackMaterials\|\|''\)/.test(cmd));
check('completion keeps packing materials out of labour',/aggMaterials\+aggPackMaterials\+aggParking\+_ccFee/.test(cmd));
check('completion records packHoursActual',/packHoursActual:aggPackHours\?/.test(cmd));
const edit=extract('saveEditedCompletedJobMultiDay');
check('edit reads per-day packing materials',/ecjmd-day-packmaterials/.test(edit)&&/packMaterials:packMaterials/.test(edit));
check('edit saves feePackMaterials and keeps it out of labour',/j\.feePackMaterials=String\(aggPackMaterials/.test(edit)&&/aggMaterials\+aggPackMaterials\+aggParking\+miscTotal/.test(edit));
check('edit total includes packing materials',/fuel\+mat\+packMat\+park/.test(extract('calcEditMultiDayTotal')));
check('edit form has a packing materials box per day',/class="ecjmd-day-packmaterials"[^>]*value="\$\{Number\(p\.packMaterials\)/.test(script));
check('packing calculator repairs old jobs first',/function calcPackMaterials\(\)\{\s*try\{if\(_healMultiDayPackMaterials\(\)\)saveDB\(\);/.test(script));
check('AI self-heal repairs old jobs first',/let healed=_healMultiDayPackMaterials\(\);/.test(script));

// --- behaviour: repair of an old multi-day job ---
const ctx={Number,Array,Math,String,console};vm.createContext(ctx);
vm.runInContext('var db;'+extract('_healMultiDayPackMaterials'),ctx);
ctx.db={completedJobs:[
  {id:'li',name:'Li Fan',multiDay:true,feePackMaterials:'',feeLabour:'3400',total:3900,
   days:[{type:'Packing',packHours:6,packMaterials:320},{type:'Moving',packHours:0,packMaterials:0}]},
  {id:'single',name:'One day',multiDay:false,feePackMaterials:'150',feeLabour:1000},
  {id:'nopack',name:'No pack',multiDay:true,feePackMaterials:'',feeLabour:2000,days:[{type:'Moving'},{type:'Moving'}]}
],aiTraining:[{completedJobId:'li',feePackMaterials:null,packHoursActual:null,actualLabour:3400},{kind:'day',completedJobId:'li',feePackMaterials:null}]};
const n1=ctx._healMultiDayPackMaterials();
const li=ctx.db.completedJobs[0];
check('old job gets feePackMaterials = per-day sum',Number(li.feePackMaterials)===320);
check('old job labour reduced by the same amount',Number(li.feeLabour)===3080);
check('saved total untouched',li.total===3900);
check('old job gets packHoursActual',li.packHoursActual===6);
check('whole-job AI record updated',ctx.db.aiTraining[0].feePackMaterials===320&&ctx.db.aiTraining[0].packHoursActual===6&&ctx.db.aiTraining[0].actualLabour===3080);
check('per-day AI record left alone',ctx.db.aiTraining[1].feePackMaterials===null);
check('single-day job untouched',ctx.db.completedJobs[1].feePackMaterials==='150'&&ctx.db.completedJobs[1]._packMatHealed===undefined);
check('multi-day job without packing materials unchanged',ctx.db.completedJobs[2].feePackMaterials===''&&Number(ctx.db.completedJobs[2].feeLabour)===2000);
const n2=ctx._healMultiDayPackMaterials();
check('repair runs once (no double subtraction)',n1===2&&n2===0&&Number(li.feeLabour)===3080);

console.log('\nRESULTS: '+pass+' passed, '+fail+' failed');
if(!fail)console.log('ALL TESTS PASSED ✅');
process.exit(fail?1:0);
