// Packing calculator: "All breakables" counts as partial packing; "Office/commercial" matches "Office / Commercial" (2026-10-01).
const {chromium}=require('playwright');
const path=require('path');
(async()=>{
  const file='file://'+path.resolve(process.argv[2]||'index.html');
  const b=await chromium.launch();const pg=await b.newPage();
  await pg.route(/supabase/,r=>r.abort());
  pg.on('dialog',d=>d.dismiss());
  await pg.goto(file);await pg.waitForTimeout(800);
  const r=await pg.evaluate(()=>{
    db.completedJobs=[
      {id:'a',name:'Breakables Bob',date:'2026-09-01',moveType:'Local move',packing:'All breakables',size:'2 bedroom',feePackMaterials:'210'},
      {id:'b',name:'Office Olga',date:'2026-09-02',moveType:'Pack and move',packing:'Full',size:'Office/commercial',feePackMaterials:'500'},
      {id:'c',name:'Just Moving Jim',date:'2026-09-03',moveType:'Local move',packing:'No',size:'2 bedroom',feePackMaterials:'90'},
      {id:'d',name:'Jeff Chen',date:'2026-09-05',moveType:'Pack and move',packing:'Full',size:'1 bedroom',feePackMaterials:'144'},
    ];
    const run=(size,type)=>{
      const s=document.getElementById('pc-size'),t=document.getElementById('pc-type');
      s.value=size;t.value=type;calcPackMaterials();
      return document.getElementById('pc-historical').textContent;
    };
    return {
      partial2:run('2 Bedroom','partial'),
      full2:run('2 Bedroom','full'),
      office:run('Office / Commercial','full'),
      one:run('1 Bedroom','full'),
    };
  });
  let pass=0,fail=0;const c=(n,v)=>{if(v)pass++;else{fail++;console.log('  ❌ '+n);}};
  c('All breakables job counts under 2 Bedroom + Partial',r.partial2.includes('Breakables Bob'));
  c('All breakables job NOT under Full pack',!r.full2.includes('Breakables Bob'));
  c('"No" packing job still excluded',!r.partial2.includes('Just Moving Jim'));
  c('Office/commercial job matches Office / Commercial',r.office.includes('Office Olga'));
  c('Jeff Chen still under 1 Bedroom + Full',r.one.includes('Jeff Chen'));
  console.log('\nRESULTS: '+pass+' passed, '+fail+' failed');if(!fail)console.log('ALL TESTS PASSED ✅');
  await b.close();process.exit(fail?1:0);
})();
