var SUPABASE_URL='https://oohqrvjhncssasjqkrzl.supabase.co';
var SUPABASE_KEY='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9vaHFydmpobmNzc2FzanFrcnpsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQ4MDY2MzIsImV4cCI6MjA5MDM4MjYzMn0.x9N_sTjBRmSrxD-LVatV9hcpPLCuWtQh6-lIMMYfxLI';
var EJS_SERVICE='service_nakq8tb';
var EJS_NOTIFY_TEMPLATE='template_nr2plwp';
var EJS_PUBLIC_KEY='76y89yZYC-kcq82ol';

function fmtMoney(n){return'$'+(Number(n)||0).toLocaleString('en-US',{minimumFractionDigits:0,maximumFractionDigits:0});}
function fmtDate(d){if(!d)return'--';if(d==='TBD')return'TBD';var dt=new Date(d+'T12:00:00');return dt.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'});}
function esc(s){var d=document.createElement('div');d.textContent=s||'';return d.innerHTML;}

function getPublicId(){
  var params=new URLSearchParams(window.location.search);
  return params.get('id');
}

async function loadQuote(){
  var publicId=getPublicId();
  if(!publicId){document.getElementById('loading').textContent='Invalid quote link. Please contact us at (415) 822-8547.';return;}
  try{
    var res=await fetch(SUPABASE_URL+'/rest/v1/quotes?select=id,data&order=created_at.desc',{
      headers:{'apikey':SUPABASE_KEY,'Authorization':'Bearer '+SUPABASE_KEY}
    });
    if(!res.ok){document.getElementById('loading').textContent='Unable to load quote (error '+res.status+'). Please contact us at (415) 822-8547.';return;}
    var rows=await res.json();
    console.log('Quotes from Supabase:',rows.length,'rows');
    console.log('Looking for publicId:',publicId);
    if(rows.length>0)console.log('First row sample:',JSON.stringify(rows[0]).slice(0,200));
    var row=rows.find(function(r){return r.data&&r.data.publicId===publicId;});
    if(!row){document.getElementById('loading').textContent='Quote not found. Please contact us at (415) 822-8547.';return;}
    var q=row.data;
    q.id=row.id;
    if(q.expiresAt&&new Date(q.expiresAt)<new Date()){
      document.getElementById('loading').style.display='none';
      document.getElementById('expired').style.display='block';
      return;
    }
    document.getElementById('loading').style.display='none';
    document.getElementById('quote-content').style.display='block';
    renderQuote(q);
  }catch(e){
    document.getElementById('loading').textContent='Error loading quote. Please contact us at (415) 822-8547.';
  }
}

function _fmtCell(p){var d=String(p||'').replace(/\D/g,'');var n=(d.length===11&&d.charAt(0)==='1')?d.slice(1):d;return n.length===10?(n.slice(0,3)+'-'+n.slice(3,6)+'-'+n.slice(6)):String(p||'');}
function renderQuote(q){
  // Ported from renderQuoteHTML in index.html — kept in sync to guarantee customer page
  // shows exactly the same content the office sees in preview.
  var isMulti=q.jobType==='multi';
  var days=q.days||[];
  var fees=(q.fees||[]).filter(function(f){return f.included;});
  var d0=days[0]||{};
  var isAccepted=q.status==='accepted';
  function fmt(n){return'$'+(Number(n)||0).toLocaleString('en-US',{minimumFractionDigits:0,maximumFractionDigits:0});}
  function fmtD(d){if(!d)return'--';if(d==='TBD')return'TBD';var dt=new Date(d+'T12:00:00');return dt.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'});}

  function renderLocs(locs,type){
    return locs.filter(function(loc){return loc&&loc.address;}).map(function(loc,i){
      return '<div style="margin-top:10px">'+
        '<div style="font-size:11px;color:#9e9b94;margin-bottom:3px">'+(i===0?(type==='load'?'Pick-up':'Drop-off'):(type==='load'?'Pick-up ':'Drop-off ')+(i+1))+'</div>'+
        '<div style="font-weight:500;font-size:14px">'+esc(loc.address+(loc.unit?', '+loc.unit:''))+'</div>'+
        (loc.floor?'<div style="font-size:12px;color:#6b6860">Floor: '+esc(loc.floor)+'</div>':'')+
        (loc.access?'<div style="font-size:12px;color:#6b6860">Access: '+esc(loc.access)+'</div>':'')+
        (loc.parking?'<div style="font-size:12px;color:#6b6860">Parking: '+esc(loc.parking)+'</div>':'')+
        '</div>';
    }).join('');
  }

  var html='<div style="font-family:DM Sans,Arial,sans-serif;color:#1a1a1a;max-width:680px;margin:0 auto">';

  // Header
  html+='<div style="text-align:center;padding:32px 24px 20px;border-bottom:2px solid #e8e4dc">'+
    '<div style="font-family:Georgia,serif;font-size:28px;font-weight:600;color:#1a1a1a;letter-spacing:-0.5px">CareMore</div>'+
    '<div style="width:60px;height:2px;background:#4a9e6b;margin:8px auto 6px"></div>'+
    '<div style="font-family:Georgia,serif;font-size:17px;font-style:italic;color:#2d5a3d">Moving &amp; Storage</div>'+
    '<div style="font-size:10px;letter-spacing:2.5px;text-transform:uppercase;color:#9e9b94;margin-top:4px">San Francisco, CA</div>'+
    '<div style="margin-top:20px;font-size:24px;font-weight:700;color:#1a1a1a">Move Estimate</div>'+
    (q.customerName?'<div style="font-size:14px;color:#6b6860;margin-top:6px">Prepared for '+esc(q.customerName)+'</div>':'')+
    (q.customerPhone?'<div style="font-size:13px;color:#9e9b94;margin-top:3px">Cell - '+esc(_fmtCell(q.customerPhone))+'</div>':'')+
    (q.customerEmail?'<div style="font-size:13px;color:#9e9b94;margin-top:3px">'+esc(q.customerEmail)+'</div>':'')+
    '<div style="font-size:12px;color:#9e9b94;margin-top:8px;line-height:1.6">CareMore Moving &amp; Storage &nbsp;&middot;&nbsp; Cal-T #0190970<br>925 Palou Ave, San Francisco, CA 94124 &nbsp;&middot;&nbsp; (415) 822-8547</div>'+
    '</div>';

  // Notes — DISABLED. Customer-facing notes are no longer rendered on the public quote page.
  // The office now types any customer-facing context manually in the confirmation email modal
  // when sending. Legacy quotes that have q.notes are still saved in storage but not displayed.
  // To re-enable, restore the if(q.notes){ ... } block.

  // Project info
  if(q.projectName||q.moveType||q.size||q.description){
    html+='<div style="padding:20px 24px;border-bottom:1px solid #e8e4dc">'+
      '<div style="font-size:10px;font-weight:600;color:#9e9b94;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:12px">Project Information</div>'+
      '<div style="font-size:14px;line-height:2;color:#333">'+
      (q.projectName?'<div><span style="color:#9e9b94;font-size:12px">Project</span><br>'+esc(q.projectName)+'</div>':'')+
      (q.moveType?'<div style="margin-top:6px"><span style="color:#9e9b94;font-size:12px">Project Type</span><br>Local Move &middot; '+esc(q.moveType)+'</div>':'')+
      (q.size?'<div style="margin-top:6px"><span style="color:#9e9b94;font-size:12px">Project Size</span><br>'+esc(q.size)+'</div>':'')+
      (q.description?'<div style="margin-top:6px"><span style="color:#9e9b94;font-size:12px">Project Description</span><br>'+esc(q.description).replace(/\n/g,'<br>')+'</div>':'')+
      '</div></div>';
  }

  // Move details
  html+='<div style="padding:20px 24px;border-bottom:1px solid #e8e4dc">'+
    '<div style="font-size:10px;font-weight:600;color:#9e9b94;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:14px">Move Details</div>';

  if(isMulti){
    days.forEach(function(d,i){
      var loads=d.loads&&d.loads.length?d.loads:[{address:d.from||'',unit:d.fromUnit||'',floor:d.fromFloor||'',access:d.fromAccess||'',parking:d.fromParking||''}];
      var unloads=d.unloads&&d.unloads.length?d.unloads:[{address:d.to||'',unit:d.toUnit||'',floor:d.toFloor||'',access:d.toAccess||'',parking:d.toParking||''}];
      html+='<div style="margin-bottom:20px;padding-bottom:16px;'+(i<days.length-1?'border-bottom:1px dashed #e8e4dc':'')+'">'+
        '<div style="font-weight:700;font-size:15px;color:#2d5a3d;margin-bottom:10px">Day '+(i+1)+(d.dayLabel?' – '+esc(d.dayLabel):'')+'</div>'+
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">'+
        (d.date?'<div><div style="font-size:11px;color:#9e9b94;margin-bottom:3px">Date</div><div style="font-weight:500;font-size:14px">'+fmtD(d.date)+'</div></div>':'')+
        (d.arrivalStart?'<div><div style="font-size:11px;color:#9e9b94;margin-bottom:3px">Arrival window</div><div style="font-weight:500;font-size:14px">'+esc(d.arrivalStart+(d.arrivalEnd?' \u2013 '+d.arrivalEnd:''))+'</div></div>':'')+
        '</div>'+
        renderLocs(loads,'load')+
        renderLocs(unloads,'unload')+
        '</div>';
    });
  } else {
    var loads=d0.loads&&d0.loads.length?d0.loads:[{address:d0.from||'',unit:d0.fromUnit||'',floor:d0.fromFloor||'',access:d0.fromAccess||'',parking:d0.fromParking||''}];
    var unloads=d0.unloads&&d0.unloads.length?d0.unloads:[{address:d0.to||'',unit:d0.toUnit||'',floor:d0.toFloor||'',access:d0.toAccess||'',parking:d0.toParking||''}];
    html+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">'+
      (d0.date?'<div><div style="font-size:11px;color:#9e9b94;margin-bottom:3px">Move date</div><div style="font-weight:500;font-size:14px">'+fmtD(d0.date)+'</div></div>':'')+
      (d0.arrivalStart?'<div><div style="font-size:11px;color:#9e9b94;margin-bottom:3px">Arrival window</div><div style="font-weight:500;font-size:14px">'+esc(d0.arrivalStart+(d0.arrivalEnd?' \u2013 '+d0.arrivalEnd:''))+'</div></div>':'')+
      '</div>'+
      renderLocs(loads,'load')+
      renderLocs(unloads,'unload');
  }
  html+='</div>';

  // Billing table
  html+='<div style="padding:20px 24px;border-bottom:1px solid #e8e4dc">'+
    '<div style="font-size:10px;font-weight:600;color:#9e9b94;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:14px">Billing</div>'+
    '<table style="width:100%;border-collapse:collapse;font-size:13.5px">'+
    '<thead><tr style="border-bottom:2px solid #e8e4dc">'+
    '<th style="text-align:left;padding:8px 6px;font-size:10px;color:#9e9b94;font-weight:500;text-transform:uppercase;letter-spacing:.8px">Description</th>'+
    '<th style="text-align:right;padding:8px 6px;font-size:10px;color:#9e9b94;font-weight:500;text-transform:uppercase;letter-spacing:.8px">Hours</th>'+
    '<th style="text-align:right;padding:8px 6px;font-size:10px;color:#9e9b94;font-weight:500;text-transform:uppercase;letter-spacing:.8px">Rate</th>'+
    '<th style="text-align:right;padding:8px 6px;font-size:10px;color:#9e9b94;font-weight:500;text-transform:uppercase;letter-spacing:.8px">Amount</th>'+
    '</tr></thead><tbody>';

  days.forEach(function(d,i){
    // When an unload crew is set, the Move crew line IS the load half of the job.
    // Crew note from the quote day, e.g. "3 Movers \u2014 packing all day" (2026-08-19). Mirrors
    // _crewNote in index.html — this file renders the CUSTOMER's page, so without it the note
    // would show in the office preview and be missing from what the customer actually receives.
    var _cn=String(d.crewNote||'').trim();
    var crewDesc=((d.unloadCrew&&d.unloadRate)
      ?((d.crewLoadDiff?(d.crewLoad||d.crew):d.crew)+' Movers \u2013 Load')
      :(d.crewLoadDiff?(d.crewLoad||d.crew)+' load / '+(d.crewUnload||d.crew)+' unload movers':d.crew+' Movers'))
      +(_cn?' \u2014 '+_cn:'');
    var label=isMulti?'Day '+(i+1)+' \u2013 '+crewDesc:crewDesc;
    if(d.flatRate){
      var flatPrice=Number(d.flatPrice)||0;
      var flatCash=Number(d.flatPriceCash)||0;
      var flatDescBase=(d.flatDescription||'').trim()||'Move services';
      var flatLabel=isMulti?'Day '+(i+1)+' \u2013 '+flatDescBase:flatDescBase;
      html+='<tr style="border-bottom:1px solid #f0ece4">'+
        '<td style="padding:11px 6px">'+esc(flatLabel)+'</td>'+
        '<td style="padding:11px 6px;text-align:right;color:#9e9b94">\u2014</td>'+
        '<td style="padding:11px 6px;text-align:right;color:#9e9b94">\u2014</td>'+
        '<td style="padding:11px 6px;text-align:right;font-weight:600">'+fmt(flatPrice)+(flatCash?'<div style="font-size:11px;color:#2d5a3d;margin-top:2px">or '+fmt(flatCash)+' cash</div>':'')+'</td>'+
        '</tr>';
    } else {
      html+='<tr style="border-bottom:1px solid #f0ece4">'+
        '<td style="padding:11px 6px">'+esc(label)+'</td>'+
        '<td style="padding:11px 6px;text-align:right;color:#6b6860">'+_qpHrText(d.hrsMin,d.hrsMax)+'</td>'+
        '<td style="padding:11px 6px;text-align:right;color:#6b6860">'+fmt(d.rate)+'/hr</td>'+
        '<td style="padding:11px 6px;text-align:right;font-weight:600">'+_qpRangeMoney(fmt,d.hrsMin*d.rate,d.hrsMax*d.rate)+'</td>'+
        '</tr>';
    }
    if(d.unloadCrew&&d.unloadRate){
      var uCount=Number(d.unloadCrewSize)||0;
      var ul=(isMulti?'Day '+(i+1)+' \u2013 ':'')+(uCount?uCount+' Movers \u2013 Unload':'Unload crew');
      html+='<tr style="border-bottom:1px solid #f0ece4">'+
        '<td style="padding:11px 6px">'+esc(ul)+'</td>'+
        '<td style="padding:11px 6px;text-align:right;color:#6b6860">'+(d.unloadHrsMin||'?')+' \u2013 '+(d.unloadHrsMax||'?')+' hrs</td>'+
        '<td style="padding:11px 6px;text-align:right;color:#6b6860">'+fmt(d.unloadRate)+'/hr</td>'+
        '<td style="padding:11px 6px;text-align:right;font-weight:600">'+fmt((d.unloadHrsMin||0)*d.unloadRate)+' \u2013 '+fmt((d.unloadHrsMax||0)*d.unloadRate)+'</td>'+
        '</tr>';
    }
    if(d.packCrew&&d.packRate){
      var pCount=Number(d.packCrewSize)||0;
      // Packing note, e.g. "2 Packers \u2014 kitchen only" (2026-10-01). Mirrors _packNote in index.html.
      var _pn=String(d.packNote||'').trim();
      var pl=(isMulti?'Day '+(i+1)+' \u2013 ':'')+(pCount?pCount+' Packer'+(pCount>1?'s':''):'Packing crew')+(_pn?' \u2014 '+_pn:'');
      html+='<tr style="border-bottom:1px solid #f0ece4">'+
        '<td style="padding:11px 6px">'+esc(pl)+'</td>'+
        '<td style="padding:11px 6px;text-align:right;color:#6b6860">'+(d.packHrsMin||'?')+' \u2013 '+(d.packHrsMax||'?')+' hrs</td>'+
        '<td style="padding:11px 6px;text-align:right;color:#6b6860">'+fmt(d.packRate)+'/hr</td>'+
        '<td style="padding:11px 6px;text-align:right;font-weight:600">'+fmt((d.packHrsMin||0)*d.packRate)+' \u2013 '+fmt((d.packHrsMax||0)*d.packRate)+'</td>'+
        '</tr>';
    }
  });

// Hours and money collapse to a SINGLE value when there is no real range (2026-08-19).
// Mirrors _hrText/_rangeMoney in index.html — this file renders the CUSTOMER's quote page, so a
// change made only in index.html would fix the office preview and leave the customer seeing
// "3 – 3 hrs" and "$675 – $675".
function _qpHrText(min,max){
  var a=Number(min)||0, b=Number(max)||0;
  if(!b||b===a)return a+' hr'+(a===1?'':'s');
  return a+'\u2013'+b+' hrs';
}
function _qpRangeMoney(fmt,minV,maxV){
  var a=Number(minV)||0, b=Number(maxV)||0;
  return (!b||Math.abs(b-a)<0.005)?fmt(a):(fmt(a)+' \u2013 '+fmt(b));
}

  fees.forEach(function(f){
    var amt=f.type==='range'?fmt(f.hrsMin||0)+' \u2013 '+fmt(f.hrsMax||0):fmt(f.amount||0);
    html+='<tr style="border-bottom:1px solid #f0ece4">'+
      '<td style="padding:11px 6px">'+esc(f.label||'')+'</td>'+
      '<td style="padding:11px 6px;text-align:right;color:#9e9b94">--</td>'+
      '<td style="padding:11px 6px;text-align:right;color:#9e9b94">--</td>'+
      '<td style="padding:11px 6px;text-align:right;font-weight:600">'+amt+'</td>'+
      '</tr>';
  });

  html+='</tbody>'+
    '<tfoot><tr style="border-top:2px solid #e8e4dc">'+
    '<td colspan="3" style="padding:14px 6px;font-weight:700;font-size:15px">'+(q.totalMin===q.totalMax?'Total':'Estimated Total')+'</td>'+
    '<td style="padding:14px 6px;text-align:right;font-weight:700;font-size:16px;color:#2d5a3d">'+(q.totalMin===q.totalMax?fmt(q.totalMin):fmt(q.totalMin)+' \u2013 '+fmt(q.totalMax))+(q.cashTotalMin?'<div style="font-size:14px;color:#2d5a3d;margin-top:4px;font-weight:600">or '+(q.cashTotalMin===q.cashTotalMax?fmt(q.cashTotalMin):fmt(q.cashTotalMin)+' \u2013 '+fmt(q.cashTotalMax))+' cash</div>':'')+'</td>'+
    '</tr></tfoot></table>'+
    (q.cashDiscount?'<div style="margin-top:12px;padding:10px 14px;background:#f0faf4;border-radius:6px;font-size:13px;color:#2d5a3d"><strong>Cash discount:</strong> '+esc(q.cashDiscount)+'</div>':'')+
    (q.storageCosts?'<div style="margin-top:12px;padding:10px 14px;background:#f0faf4;border-radius:6px;font-size:13px;color:#2d5a3d"><strong>Storage costs:</strong> '+esc(q.storageCosts)+'</div>':'')+
    '</div>';

  // Stipulations
  if(q.stipulations){
    html+='<div style="padding:20px 24px;border-bottom:1px solid #e8e4dc">'+
      '<div style="font-size:10px;font-weight:600;color:#9e9b94;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:10px">Terms &amp; Conditions</div>'+
      '<div style="font-size:13px;color:#555;line-height:1.9;white-space:pre-wrap">'+esc(q.stipulations)+'</div>'+
      '</div>';
  }

  // Accept / accepted section
  if(isAccepted){
    html+='<div style="padding:24px;text-align:center;background:#f0faf4;border-radius:0 0 8px 8px">'+
      '<div style="font-size:32px;color:#2d5a3d">&#10003;</div>'+
      '<div style="font-size:18px;font-weight:700;color:#2d5a3d;margin:8px 0">Quote accepted!</div>'+
      '<p style="font-size:14px;color:#6b6860;margin-bottom:8px">Thank you, '+esc((q.customerName||'').split(' ')[0])+'! We have received your acceptance and we will be in touch within 2 business days to confirm what dates are available for your move.</p>'+
      '<div style="font-size:13px;color:#9e9b94">(415) 822-8547 &nbsp;&middot;&nbsp; move@caremoremoving.com</div>'+
      '</div>';
  } else {
    html+='<div style="padding:24px;text-align:center;background:#f9f7f4">'+
      '<div style="font-size:16px;font-weight:700;margin-bottom:8px;color:#1a1a1a">Ready to move forward?</div>'+
      '<div style="font-size:13px;color:#6b6860;margin-bottom:18px;line-height:1.7;max-width:480px;margin-left:auto;margin-right:auto">Click below to accept this quote. We will be in touch within 2 business days to confirm your booking. Please note: the move is not confirmed until we confirm that the date(s) are available and we send you a confirmation email.</div>'+
      '<button id="accept-btn" onclick="acceptQuote(\''+q.id+'\',\''+q.publicId+'\')" style="background:#2d5a3d;color:#fff;border:none;padding:16px 48px;border-radius:8px;font-size:16px;font-weight:600;cursor:pointer">&#10003; &nbsp;Accept Quote</button>'+
      '</div>';
  }

  if(q.sentBy){
    html+='<div style="text-align:right;padding:12px 24px;font-size:12px;color:#9e9b94">Quote prepared by '+esc(q.sentBy)+'</div>';
  }

  html+='<div style="text-align:center;padding:16px 24px;font-size:12px;color:#9e9b94;border-top:1px solid #e8e4dc">Questions? Call <a href="tel:4158228547" style="color:#2d5a3d;font-weight:500">(415) 822-8547</a> or email <a href="mailto:move@caremoremoving.com" style="color:#2d5a3d;font-weight:500">move@caremoremoving.com</a></div>';
  html+='</div>';

  document.getElementById('quote-content').innerHTML=html;
  window._currentQuote=q;
}

async function acceptQuote(quoteId,publicId){
  var btn=document.getElementById('accept-btn');
  if(btn){btn.disabled=true;btn.textContent='Accepting...';}
  var acceptedAt=new Date().toISOString();

  // CRITICAL: Do NOT write window._currentQuote back to Supabase. That would let a stale
  // browser tab overwrite the real saved quote with old/corrupted data — the exact bug that
  // locked in Matt Fickett's corruption on 2026-05-28. Instead, fetch the LATEST row from
  // Supabase, merge in just status='accepted' + acceptedAt, and write that back. The customer's
  // cached _currentQuote is only used for the notification email body — not for the PATCH.
  try{
    // Step 1: fetch the latest quote row from Supabase
    var fetchRes=await fetch(SUPABASE_URL+'/rest/v1/quotes?id=eq.'+quoteId,{
      headers:{'apikey':SUPABASE_KEY,'Authorization':'Bearer '+SUPABASE_KEY}
    });
    if(!fetchRes.ok){
      console.error('acceptQuote: failed to fetch latest quote',fetchRes.status);
      throw new Error('Could not load latest quote (HTTP '+fetchRes.status+')');
    }
    var rows=await fetchRes.json();
    if(!rows.length){
      throw new Error('Quote not found in Supabase');
    }
    var latestQ=rows[0].data||rows[0];

    // Step 2: refuse to overwrite a quote that's already accepted (idempotency + safety)
    if(latestQ.status==='accepted'&&latestQ.acceptedAt){
      console.log('acceptQuote: quote already accepted at',latestQ.acceptedAt,'— treating as already-done');
      window._currentQuote=latestQ;
      renderQuote(latestQ);
      return;
    }

    // Step 3: merge ONLY the acceptance fields into the latest version. The customer's browser
    // copy of the quote is irrelevant — we only touch status + acceptedAt.
    var updated=Object.assign({},latestQ,{status:'accepted',acceptedAt:acceptedAt});

    // Step 4: PATCH with the merged latest data
    var patchRes=await fetch(SUPABASE_URL+'/rest/v1/quotes?id=eq.'+quoteId,{
      method:'PATCH',
      headers:{'apikey':SUPABASE_KEY,'Authorization':'Bearer '+SUPABASE_KEY,'Content-Type':'application/json','Prefer':'return=minimal'},
      body:JSON.stringify({data:updated})
    });
    if(!patchRes.ok){
      throw new Error('Could not save acceptance (HTTP '+patchRes.status+')');
    }

    // Step 5: notification email to office. Use the LATEST quote for the email body so the
    // numbers we tell the office about are the real saved numbers, not what the customer's
    // stale browser had cached.
    try{
      var s=document.createElement('script');
      s.src='https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js';
      s.onload=function(){
        emailjs.init({publicKey:EJS_PUBLIC_KEY});
        var name=updated.customerName||'Customer';
        var d0=updated.days&&updated.days[0]||{};
        var quoteLink='https://davidabram217.github.io/movedesk/quote.html?id='+(updated.publicId||publicId||'');
        var body=name+' has accepted their move quote.\n\nCustomer: '+name+'\nEmail: '+(updated.customerEmail||'--')+'\nMove date: '+(d0.date?fmtDate(d0.date):'--')+'\nQuote total: '+fmtMoney(updated.totalMin)+' - '+fmtMoney(updated.totalMax)+'\nAccepted: '+new Date(acceptedAt).toLocaleString()+'\n\nView the accepted quote:\n'+quoteLink+'\n\nLog in to MoveDesk:\nhttps://davidabram217.github.io/movedesk';
        emailjs.send(EJS_SERVICE,EJS_NOTIFY_TEMPLATE,{to_email:'move@caremoremoving.com',to_name:'CareMore Moving and Storage',from_name:'CareMore Moving and Storage',reply_to:'move@caremoremoving.com',subject:'Quote accepted - '+name+' ('+fmtMoney(updated.totalMin)+' - '+fmtMoney(updated.totalMax)+')',message:body,html_content:'<pre style="font-family:Arial,sans-serif;font-size:14px;white-space:pre-wrap">'+body+'</pre>'});
      };
      document.head.appendChild(s);
    }catch(e){console.log('Notification failed:',e);}
    window._currentQuote=updated;
    renderQuote(updated);
  }catch(e){
    console.error('acceptQuote error:',e);
    if(btn){btn.disabled=false;btn.textContent='Accept Quote';}
    alert('Something went wrong. Please call us at (415) 822-8547.');
  }
}

loadQuote();
