// Pod / truck size on lead, completion, AI training and AI quote (2026-10-01).
const fs=require('fs'),vm=require('vm');
const idx=fs.readFileSync(process.argv[2]||'index.html','utf8');
const script=idx.slice(idx.indexOf('<script>')+8,idx.lastIndexOf('</script>'));
let pass=0,fail=0;const check=(n,c)=>{if(c)pass++;else{fail++;console.log('  ❌ '+n);}};
function ex(name){const m=new RegExp('function\\s+'+name+'\\s*\\(').exec(script);let i=script.indexOf('{',m.index),d=0,s=false,sc='',t=false,e=false;for(let p=i;p<script.length;p++){const c=script[p];if(e){e=false;continue;}if(c==='\\'){e=true;continue;}if(s){if(c===sc)s=false;continue;}if(t){if(c==='`')t=false;continue;}if(c==='"'||c==="'"){s=true;sc=c;continue;}if(c==='`'){t=true;continue;}if(c==='{')d++;else if(c==='}'){d--;if(d===0)return script.slice(m.index,p+1);}}}
const i=script.indexOf('const CONTAINER_SIZES=[');const j=script.indexOf('];',i)+2;
const ctx={String,Number,Math};vm.createContext(ctx);vm.runInContext(script.slice(i,j).replace('const ','var ')+ex('_isPodTruckType')+ex('_containerCuft')+ex('accessScore')+ex('similarity'),ctx);
check('pod/truck move types detected',ctx._isPodTruckType('Load pod / truck only')&&ctx._isPodTruckType('Unload pod / truck only')&&!ctx._isPodTruckType('Move'));
check('cu ft lookup',ctx._containerCuft('16 ft container')===1000&&ctx._containerCuft('26 ft truck')===1700&&ctx._containerCuft('Other / not sure')===null);
const base={accessLoad:'Flat',accessUnload:'Flat'};
const s=(a,b)=>ctx.similarity({...base,containerSize:a},{...base,containerSize:b});
check('same size scores highest',s('16 ft container','16 ft container')>s('15 ft truck','16 ft container')&&s('15 ft truck','16 ft container')>s('26 ft truck','16 ft container'));
check('twice the size adds nothing',s('8 ft container (PODS etc.)','16 ft container')===s('','16 ft container'));
check('field on all six forms',['ai','nl','cj','cjmd','ecjmd','qb'].every(p=>idx.includes('id="'+p+'-container-wrap"')&&idx.includes('id="'+p+'-container"')));
check('lead saves + edit restores',/l\.containerSize=\(typeof _readContainer==='function'\)\?_readContainer\('nl'\)/.test(script)&&/_syncContainerField\('nl',l\.containerSize\|\|''\);/.test(script)&&/containerSize:_readContainer\('nl'\),/.test(script));
check('single + multi completion prefill from job or lead',/_syncContainerField\('cj',j\.containerSize\|\|\(_lead&&_lead\.containerSize\)\|\|''\);/.test(script)&&/_syncContainerField\('cjmd',j\.containerSize\|\|\(_l&&_l\.containerSize\)\|\|''\);/.test(script));
check('completions + edit save it',/containerSize:_readContainer\('cj'\)/.test(script)&&/containerSize:_readContainer\('cjmd'\)/.test(script)&&/j\.containerSize=_readContainer\('ecjmd'\);/.test(script));
check('all AI training builders carry it',(script.match(/containerSize:j\.containerSize\|\|''/g)||[]).length>=3&&/containerSize:completed\.containerSize\|\|''/.test(script));
check('AI quote input + draft',/containerSize:_readContainer\('ai'\),/.test(script)&&/'ai-movetype','ai-container',/.test(script));
check('volume guard uses size',/if\(_ic&&_jc\)return Math\.max\(_ic,_jc\)\/Math\.min\(_ic,_jc\)<=VOL_RATIO_MAX;/.test(script));
check('hidden unless pod/truck move type',/wrap\.style\.display=_isPodTruckType\(mt\)\?'':'none';/.test(script)&&/if\(!_isPodTruckType\(mt\)\)return '';/.test(script));
const qp=fs.readFileSync('quote-page.js','utf8');
check('quote builder prefills from lead / saved quote',/_syncContainerField\('qb',l\?\.containerSize\|\|''\)/.test(script)&&/_syncContainerField\('qb',q\.containerSize\|\|l\?\.containerSize\|\|''\)/.test(script));
check('saved quote + preview carry it',(script.match(/containerSize:\(typeof _readContainer==='function'\)\?_readContainer\('qb'\):''/g)||[]).length===2);
check('office preview + customer page show it identically',/\$\{q\.containerSize\?' · '\+esc\(q\.containerSize\):''\}/.test(script)&&/\(q\.containerSize\?' &middot; '\+esc\(q\.containerSize\):''\)/.test(qp));
check('booking copies size (lead, else latest quote)',/containerSize:\(l&&l\.containerSize\)\|\|/.test(script));
check('crew sheet says Load/Unload <size>',/bits\.push\(\(\/\^unload\/i/.test(script)&&/facts\.push\(\(\/\^unload\/i/.test(script));
console.log('\nRESULTS: '+pass+' passed, '+fail+' failed');if(!fail)console.log('ALL TESTS PASSED ✅');process.exit(fail?1:0);
